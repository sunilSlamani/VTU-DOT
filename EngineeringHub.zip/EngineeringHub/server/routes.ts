import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { loginSchema, insertUserSchema, searchSchema, uploadMaterialSchema } from "@shared/schema";
import { ZodError } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import express from "express";

// Configure multer for file uploads
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadsDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
  }),
  limits: {
    fileSize: 50 * 1024 * 1024 // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.pdf', '.doc', '.docx', '.ppt', '.pptx', '.txt'];
    const fileExtension = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(fileExtension)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, DOC, DOCX, PPT, PPTX, and TXT files are allowed.'));
    }
  }
});

// Middleware to check if user is admin
const requireAdmin = async (req: any, res: any, next: any) => {
  try {
    const userId = req.session?.userId;
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = await storage.getUser(userId);
    if (!user || !user.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }
    
    req.user = user;
    next();
  } catch (error) {
    res.status(500).json({ message: "Internal server error" });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Store user session (simplified - in production use proper session management)
      req.session = req.session || {};
      (req.session as any).userId = user.id;
      
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username or email already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already registered" });
      }

      const user = await storage.createUser(userData);
      const { password: _, ...userWithoutPassword } = user;
      
      res.status(201).json({ user: userWithoutPassword });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session = null;
    res.json({ message: "Logged out successfully" });
  });

  app.get("/api/auth/me", async (req, res) => {
    const userId = (req.session as any)?.userId;
    if (!userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }

    const { password: _, ...userWithoutPassword } = user;
    res.json({ user: userWithoutPassword });
  });

  // Branch routes
  app.get("/api/branches", async (req, res) => {
    try {
      const branches = await storage.getAllBranches();
      res.json(branches);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/branches/:code", async (req, res) => {
    try {
      const { code } = req.params;
      const branch = await storage.getBranchByCode(code);
      
      if (!branch) {
        return res.status(404).json({ message: "Branch not found" });
      }
      
      res.json(branch);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Material routes
  app.get("/api/materials", async (req, res) => {
    try {
      const { branch, type, semester } = req.query;
      let materials;

      if (branch && type) {
        materials = await storage.getMaterialsByBranchAndType(branch as string, type as string);
      } else if (branch) {
        materials = await storage.getMaterialsByBranch(branch as string);
      } else if (type) {
        materials = await storage.getMaterialsByType(type as string);
      } else if (semester) {
        materials = await storage.getMaterialsBySemester(parseInt(semester as string));
      } else {
        materials = await storage.getAllMaterials();
      }

      res.json(materials);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/materials/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const material = await storage.getMaterial(id);
      
      if (!material) {
        return res.status(404).json({ message: "Material not found" });
      }
      
      res.json(material);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Search route
  app.post("/api/search", async (req, res) => {
    try {
      const { query, branch, semester, type } = searchSchema.parse(req.body);
      
      const results = await storage.searchMaterials(query, {
        branch,
        semester,
        type
      });
      
      res.json(results);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid search parameters", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Download route
  app.post("/api/materials/:id/download", async (req, res) => {
    try {
      const materialId = parseInt(req.params.id);
      const userId = (req.session as any)?.userId || null;
      
      const material = await storage.getMaterial(materialId);
      if (!material) {
        return res.status(404).json({ message: "Material not found" });
      }

      // Record the download
      await storage.recordDownload(userId, materialId);
      
      // Update download count
      await storage.updateMaterialDownloadCount(materialId);
      
      res.json({ 
        message: "Download recorded", 
        fileUrl: material.fileUrl,
        fileName: `${material.title}.${material.fileType}`
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Statistics route
  app.get("/api/stats", async (req, res) => {
    try {
      const branches = await storage.getAllBranches();
      const materials = await storage.getAllMaterials();
      const studyMaterials = materials.filter(m => m.type === 'study_material');
      const questionPapers = materials.filter(m => m.type === 'question_paper');
      const labManuals = materials.filter(m => m.type === 'lab_manual');

      res.json({
        branches: branches.length,
        materials: studyMaterials.length,
        papers: questionPapers.length,
        labs: labManuals.length
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin file upload routes
  app.post("/api/admin/upload", requireAdmin, upload.single('file'), async (req: any, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const materialData = uploadMaterialSchema.parse(req.body);
      
      // Create material record in database
      const material = await storage.createMaterial({
        ...materialData,
        fileUrl: `/uploads/${req.file.filename}`,
        fileType: path.extname(req.file.originalname).slice(1),
        fileSize: req.file.size,
        uploadedBy: req.user.id
      });

      res.json({
        message: "File uploaded successfully",
        material: {
          id: material.id,
          title: material.title,
          type: material.type,
          branchCode: material.branchCode,
          semester: material.semester,
          subject: material.subject,
          fileType: material.fileType,
          fileSize: material.fileSize
        }
      });
    } catch (error) {
      // Clean up uploaded file if database operation fails
      if (req.file && fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid material data", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', (req, res, next) => {
    // Add some basic security headers for file downloads
    res.setHeader('Content-Security-Policy', "default-src 'none'");
    res.setHeader('X-Content-Type-Options', 'nosniff');
    next();
  });
  
  app.use('/uploads', express.static(uploadsDir));

  // Admin routes to manage materials
  app.get("/api/admin/materials", requireAdmin, async (req, res) => {
    try {
      const materials = await storage.getAllMaterials();
      res.json(materials);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/admin/materials/:id", requireAdmin, async (req, res) => {
    try {
      const materialId = parseInt(req.params.id);
      const material = await storage.getMaterial(materialId);
      
      if (!material) {
        return res.status(404).json({ message: "Material not found" });
      }

      // Deactivate the material instead of deleting
      await storage.updateMaterial(materialId, { isActive: false });
      
      res.json({ message: "Material removed successfully" });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
