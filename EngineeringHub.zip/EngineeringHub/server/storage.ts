import { users, branches, materials, downloads, type User, type InsertUser, type Branch, type InsertBranch, type Material, type InsertMaterial, type Download } from "@shared/schema";
import { db } from "./db";
import { eq, like, and } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;

  // Branch methods
  getAllBranches(): Promise<Branch[]>;
  getBranchByCode(code: string): Promise<Branch | undefined>;
  createBranch(branch: InsertBranch): Promise<Branch>;

  // Material methods
  getAllMaterials(): Promise<Material[]>;
  getMaterialsByBranch(branchCode: string): Promise<Material[]>;
  getMaterialsByType(type: string): Promise<Material[]>;
  getMaterialsByBranchAndType(branchCode: string, type: string): Promise<Material[]>;
  getMaterialsBySemester(semester: number): Promise<Material[]>;
  getMaterial(id: number): Promise<Material | undefined>;
  createMaterial(material: InsertMaterial): Promise<Material>;
  updateMaterial(id: number, updates: Partial<Material>): Promise<Material | undefined>;
  updateMaterialDownloadCount(id: number): Promise<void>;
  searchMaterials(query: string, filters?: { branch?: string; semester?: number; type?: string }): Promise<Material[]>;

  // Download methods
  recordDownload(userId: number | null, materialId: number): Promise<Download>;
  getUserDownloads(userId: number): Promise<Download[]>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    this.initializeDefaultData();
  }

  private async initializeDefaultData() {
    try {
      // Check if branches already exist
      const existingBranches = await db.select().from(branches).limit(1);
      if (existingBranches.length > 0) {
        return; // Data already initialized
      }

      // Initialize default branches
      const defaultBranches = [
        { code: 'cse', name: 'Computer Science Engineering', description: 'Programming, algorithms, software development, and computer systems', icon: 'fas fa-laptop-code', isActive: true },
        { code: 'ece', name: 'Electronics & Communication', description: 'Digital electronics, communication systems, and signal processing', icon: 'fas fa-microchip', isActive: true },
        { code: 'mech', name: 'Mechanical Engineering', description: 'Thermodynamics, mechanics, manufacturing, and design', icon: 'fas fa-cogs', isActive: true },
        { code: 'civil', name: 'Civil Engineering', description: 'Structural engineering, construction, and infrastructure development', icon: 'fas fa-building', isActive: true },
        { code: 'eee', name: 'Electrical Engineering', description: 'Power systems, electrical machines, and control systems', icon: 'fas fa-bolt', isActive: true },
        { code: 'ise', name: 'Information Science', description: 'Information systems, databases, and software engineering', icon: 'fas fa-database', isActive: true }
      ];

      await db.insert(branches).values(defaultBranches);

      // Initialize comprehensive sample materials for all branches
      const sampleMaterials = [
        // Computer Science Engineering
        { title: 'Data Structures and Algorithms', description: 'Complete notes covering arrays, linked lists, trees, graphs, sorting and searching algorithms with time complexity analysis', type: 'study_material', branchCode: 'cse', semester: 3, subject: 'Data Structures', fileUrl: '/materials/dsa-notes.pdf', fileType: 'pdf', fileSize: 2048, downloadCount: 1200, examDate: null, uploadedBy: null, isActive: true },
        { title: 'Database Management Systems', description: 'Comprehensive guide to SQL, normalization, database design principles, transactions, and ACID properties', type: 'study_material', branchCode: 'cse', semester: 4, subject: 'DBMS', fileUrl: '/materials/dbms-notes.doc', fileType: 'doc', fileSize: 1536, downloadCount: 856, examDate: null, uploadedBy: null, isActive: true },
        { title: 'Computer Networks', description: 'Network protocols, OSI model, TCP/IP stack, network security fundamentals, and routing algorithms', type: 'study_material', branchCode: 'cse', semester: 5, subject: 'Computer Networks', fileUrl: '/materials/networks-slides.ppt', fileType: 'ppt', fileSize: 3072, downloadCount: 743, examDate: null, uploadedBy: null, isActive: true },
        { title: 'Operating Systems', description: 'Process management, memory management, file systems, deadlocks, and synchronization mechanisms', type: 'study_material', branchCode: 'cse', semester: 4, subject: 'Operating Systems', fileUrl: '/materials/os-complete.pdf', fileType: 'pdf', fileSize: 3500, downloadCount: 980, examDate: null, uploadedBy: null, isActive: true },
        { title: 'Software Engineering', description: 'SDLC models, requirements analysis, design patterns, testing methodologies, and project management', type: 'study_material', branchCode: 'cse', semester: 6, subject: 'Software Engineering', fileUrl: '/materials/se-notes.pdf', fileType: 'pdf', fileSize: 2800, downloadCount: 654, examDate: null, uploadedBy: null, isActive: true },
        
        // Electronics & Communication
        { title: 'Digital Signal Processing', description: 'DFT, FFT, FIR/IIR filters, Z-transform, and digital filter design techniques', type: 'study_material', branchCode: 'ece', semester: 5, subject: 'Digital Signal Processing', fileUrl: '/materials/dsp-notes.pdf', fileType: 'pdf', fileSize: 2200, downloadCount: 567, examDate: null, uploadedBy: null, isActive: true },
        { title: 'Analog Electronics', description: 'BJT, FET, operational amplifiers, oscillators, and power amplifiers design', type: 'study_material', branchCode: 'ece', semester: 3, subject: 'Analog Electronics', fileUrl: '/materials/analog-electronics.pdf', fileType: 'pdf', fileSize: 1890, downloadCount: 789, examDate: null, uploadedBy: null, isActive: true },
        { title: 'Communication Systems', description: 'Amplitude/frequency modulation, digital modulation techniques, and wireless communication', type: 'study_material', branchCode: 'ece', semester: 6, subject: 'Communication Systems', fileUrl: '/materials/comm-systems.pdf', fileType: 'pdf', fileSize: 2650, downloadCount: 432, examDate: null, uploadedBy: null, isActive: true },
        
        // Question Papers
        { title: 'Data Structures - Final Exam 2023', description: 'VTU final semester examination with detailed solutions, marking scheme, and time allocation guide', type: 'question_paper', branchCode: 'cse', semester: 3, subject: 'Data Structures', fileUrl: '/papers/dsa-final-2023.pdf', fileType: 'pdf', fileSize: 1024, downloadCount: 2100, examDate: 'Dec 2023', uploadedBy: null, isActive: true },
        { title: 'DBMS - Mid Semester 2023', description: 'Mid-term examination questions covering SQL queries, normalization, and database design', type: 'question_paper', branchCode: 'cse', semester: 4, subject: 'DBMS', fileUrl: '/papers/dbms-mid-2023.pdf', fileType: 'pdf', fileSize: 512, downloadCount: 1800, examDate: 'Jun 2023', uploadedBy: null, isActive: true },
        
        // Lab Manuals
        { title: 'C Programming Lab Manual', description: 'Complete C programming exercises with sample code, expected outputs, and debugging tips', type: 'lab_manual', branchCode: 'cse', semester: 1, subject: 'Programming', fileUrl: '/labs/c-programming-lab.pdf', fileType: 'pdf', fileSize: 2560, downloadCount: 1500, examDate: null, uploadedBy: null, isActive: true },
        { title: 'Database Lab Manual', description: 'SQL queries, database creation, stored procedures, and practical database exercises', type: 'lab_manual', branchCode: 'cse', semester: 4, subject: 'DBMS', fileUrl: '/labs/dbms-lab.pdf', fileType: 'pdf', fileSize: 1800, downloadCount: 1200, examDate: null, uploadedBy: null, isActive: true }
      ];

      await db.insert(materials).values(sampleMaterials);
    } catch (error) {
      console.error('Error initializing default data:', error);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        studentId: insertUser.studentId || null,
        branch: insertUser.branch || null,
        semester: insertUser.semester || null,
        isActive: insertUser.isActive ?? true
      })
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getAllBranches(): Promise<Branch[]> {
    return await db.select().from(branches).where(eq(branches.isActive, true));
  }

  async getBranchByCode(code: string): Promise<Branch | undefined> {
    const [branch] = await db
      .select()
      .from(branches)
      .where(and(eq(branches.code, code), eq(branches.isActive, true)));
    return branch || undefined;
  }

  async createBranch(insertBranch: InsertBranch): Promise<Branch> {
    const [branch] = await db
      .insert(branches)
      .values({
        ...insertBranch,
        isActive: insertBranch.isActive ?? true
      })
      .returning();
    return branch;
  }

  async getAllMaterials(): Promise<Material[]> {
    return await db.select().from(materials).where(eq(materials.isActive, true));
  }

  async getMaterialsByBranch(branchCode: string): Promise<Material[]> {
    return await db
      .select()
      .from(materials)
      .where(and(eq(materials.branchCode, branchCode), eq(materials.isActive, true)));
  }

  async getMaterialsByType(type: string): Promise<Material[]> {
    return await db
      .select()
      .from(materials)
      .where(and(eq(materials.type, type), eq(materials.isActive, true)));
  }

  async getMaterialsByBranchAndType(branchCode: string, type: string): Promise<Material[]> {
    return await db
      .select()
      .from(materials)
      .where(and(
        eq(materials.branchCode, branchCode),
        eq(materials.type, type),
        eq(materials.isActive, true)
      ));
  }

  async getMaterialsBySemester(semester: number): Promise<Material[]> {
    return await db
      .select()
      .from(materials)
      .where(and(eq(materials.semester, semester), eq(materials.isActive, true)));
  }

  async getMaterial(id: number): Promise<Material | undefined> {
    const [material] = await db
      .select()
      .from(materials)
      .where(and(eq(materials.id, id), eq(materials.isActive, true)));
    return material || undefined;
  }

  async createMaterial(insertMaterial: InsertMaterial): Promise<Material> {
    const [material] = await db
      .insert(materials)
      .values({
        ...insertMaterial,
        downloadCount: 0,
        fileSize: insertMaterial.fileSize || null,
        examDate: insertMaterial.examDate || null,
        uploadedBy: insertMaterial.uploadedBy || null,
        isActive: insertMaterial.isActive ?? true
      })
      .returning();
    return material;
  }

  async updateMaterial(id: number, updates: Partial<Material>): Promise<Material | undefined> {
    const [material] = await db
      .update(materials)
      .set(updates)
      .where(eq(materials.id, id))
      .returning();
    return material || undefined;
  }

  async updateMaterialDownloadCount(id: number): Promise<void> {
    const material = await this.getMaterial(id);
    if (material) {
      await db
        .update(materials)
        .set({ downloadCount: (material.downloadCount || 0) + 1 })
        .where(eq(materials.id, id));
    }
  }

  async searchMaterials(query: string, filters?: { branch?: string; semester?: number; type?: string }): Promise<Material[]> {
    const conditions = [eq(materials.isActive, true)];
    
    // Add filter conditions
    if (filters?.branch) {
      conditions.push(eq(materials.branchCode, filters.branch));
    }
    if (filters?.semester) {
      conditions.push(eq(materials.semester, filters.semester));
    }
    if (filters?.type) {
      conditions.push(eq(materials.type, filters.type));
    }

    // Add search conditions using OR for title, description, or subject
    conditions.push(
      eq(
        1,
        // Simple search implementation - could be improved with full-text search
        1
      )
    );

    const results = await db
      .select()
      .from(materials)
      .where(and(...conditions));

    // Filter results in memory for now (could be optimized with database search)
    return results.filter(material => 
      material.title.toLowerCase().includes(query.toLowerCase()) ||
      material.description.toLowerCase().includes(query.toLowerCase()) ||
      material.subject.toLowerCase().includes(query.toLowerCase())
    );
  }

  async recordDownload(userId: number | null, materialId: number): Promise<Download> {
    const [download] = await db
      .insert(downloads)
      .values({
        userId,
        materialId
      })
      .returning();
    return download;
  }

  async getUserDownloads(userId: number): Promise<Download[]> {
    return await db
      .select()
      .from(downloads)
      .where(eq(downloads.userId, userId));
  }
}

export const storage = new DatabaseStorage();
