import { queryClient } from "./queryClient";

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface RegisterData {
  username: string;
  password: string;
  name: string;
  email: string;
  studentId?: string;
  branch?: string;
  semester?: number;
}

export function setAuthSession(user: any) {
  localStorage.setItem('vtud_session', JSON.stringify(user));
  queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
}

export function clearAuthSession() {
  localStorage.removeItem('vtud_session');
  queryClient.clear();
}

export function getStoredSession() {
  try {
    const session = localStorage.getItem('vtud_session');
    return session ? JSON.parse(session) : null;
  } catch {
    return null;
  }
}
