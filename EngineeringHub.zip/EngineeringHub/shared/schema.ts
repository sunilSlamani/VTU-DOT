import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  studentId: text("student_id"),
  branch: text("branch"),
  semester: integer("semester"),
  isAdmin: boolean("is_admin").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow()
});

export const branches = pgTable("branches", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  isActive: boolean("is_active").default(true)
});

export const materials = pgTable("materials", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // 'study_material', 'question_paper', 'lab_manual'
  branchCode: text("branch_code").notNull(),
  semester: integer("semester").notNull(),
  subject: text("subject").notNull(),
  fileUrl: text("file_url").notNull(),
  fileType: text("file_type").notNull(), // 'pdf', 'doc', 'ppt', etc.
  fileSize: integer("file_size"),
  downloadCount: integer("download_count").default(0),
  examDate: text("exam_date"), // for question papers
  uploadedBy: integer("uploaded_by"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow()
});

export const downloads = pgTable("downloads", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  materialId: integer("material_id").notNull(),
  downloadedAt: timestamp("downloaded_at").defaultNow()
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true
});

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(6, "Password must be at least 6 characters")
});

export const insertBranchSchema = createInsertSchema(branches).omit({
  id: true
});

export const insertMaterialSchema = createInsertSchema(materials).omit({
  id: true,
  downloadCount: true,
  createdAt: true
});

export const searchSchema = z.object({
  query: z.string().min(1),
  branch: z.string().optional(),
  semester: z.number().optional(),
  type: z.enum(['study_material', 'question_paper', 'lab_manual']).optional()
});

export const uploadMaterialSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  type: z.enum(['study_material', 'question_paper', 'lab_manual']),
  branchCode: z.string().min(1, "Branch is required"),
  semester: z.number().min(1).max(8),
  subject: z.string().min(1, "Subject is required"),
  examDate: z.string().optional()
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginRequest = z.infer<typeof loginSchema>;
export type Branch = typeof branches.$inferSelect;
export type InsertBranch = z.infer<typeof insertBranchSchema>;
export type Material = typeof materials.$inferSelect;
export type InsertMaterial = z.infer<typeof insertMaterialSchema>;
export type Download = typeof downloads.$inferSelect;
export type SearchRequest = z.infer<typeof searchSchema>;
export type UploadMaterialRequest = z.infer<typeof uploadMaterialSchema>;
