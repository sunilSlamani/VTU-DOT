export interface AppStats {
  branches: number;
  materials: number;
  papers: number;
  labs: number;
}

export interface AuthUser {
  id: number;
  username: string;
  name: string;
  email: string;
  studentId?: string;
  branch?: string;
  semester?: number;
  isAdmin?: boolean;
  isActive: boolean;
}

export interface BranchData {
  id: number;
  code: string;
  name: string;
  description: string;
  icon: string;
}

export interface MaterialData {
  id: number;
  title: string;
  description: string;
  type: 'study_material' | 'question_paper' | 'lab_manual';
  branchCode: string;
  semester: number;
  subject: string;
  fileUrl: string;
  fileType: string;
  fileSize?: number;
  downloadCount: number;
  examDate?: string;
  isActive: boolean;
  createdAt: Date;
}

export interface SearchFilters {
  branch?: string;
  semester?: number;
  type?: 'study_material' | 'question_paper' | 'lab_manual';
}
