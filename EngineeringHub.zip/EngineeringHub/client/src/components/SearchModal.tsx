import { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, X, FileText, Download } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { MaterialData } from "@/types";

const searchSchema = z.object({
  query: z.string().min(1)
});

interface SearchModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SearchModal({ open, onOpenChange }: SearchModalProps) {
  const [searchResults, setSearchResults] = useState<MaterialData[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const { register, handleSubmit, watch, reset } = useForm<{ query: string }>({
    defaultValues: { query: "" }
  });

  const query = watch("query");

  const searchMutation = useMutation({
    mutationFn: async (data: { query: string }) => {
      const response = await apiRequest('POST', '/api/search', data);
      return response.json();
    },
    onSuccess: (results) => {
      setSearchResults(results);
      setIsSearching(false);
    },
    onError: () => {
      setSearchResults([]);
      setIsSearching(false);
    }
  });

  const downloadMutation = useMutation({
    mutationFn: async (materialId: number) => {
      const response = await apiRequest('POST', `/api/materials/${materialId}/download`);
      return response.json();
    },
    onSuccess: (data) => {
      // Create download link
      const link = document.createElement('a');
      link.href = data.fileUrl;
      link.download = data.fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  });

  const onSearch = (data: { query: string }) => {
    if (data.query.trim()) {
      setIsSearching(true);
      searchMutation.mutate(data);
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    reset();
    setSearchResults([]);
    setIsSearching(false);
  };

  const getFileIcon = (fileType: string) => {
    return <FileText className="h-4 w-4" />;
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'study_material':
        return 'bg-blue-100 text-blue-700';
      case 'question_paper':
        return 'bg-red-100 text-red-700';
      case 'lab_manual':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'study_material':
        return 'Study Material';
      case 'question_paper':
        return 'Question Paper';
      case 'lab_manual':
        return 'Lab Manual';
      default:
        return type;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] p-0">
        <div className="p-6 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              {...register("query")}
              placeholder="Search study materials, question papers, lab manuals..."
              className="pl-10 pr-10 py-3 text-base focus:ring-2 focus:ring-primary focus:border-transparent"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleSubmit(onSearch)();
                }
              }}
            />
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-1 top-1"
              onClick={handleClose}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          
          {query && (
            <div className="mt-4 flex gap-2">
              <Button
                onClick={handleSubmit(onSearch)}
                disabled={isSearching}
                className="bg-primary hover:bg-blue-700"
              >
                {isSearching ? "Searching..." : "Search"}
              </Button>
            </div>
          )}
        </div>

        <ScrollArea className="max-h-96 p-6">
          {!query && (
            <div>
              <div className="text-sm text-gray-500 mb-3">Recent searches</div>
              <div className="space-y-2">
                <div className="p-3 hover:bg-gray-50 rounded-lg cursor-pointer">
                  <div className="font-medium">Data Structures Question Papers</div>
                  <div className="text-sm text-gray-500">Computer Science - 3rd Semester</div>
                </div>
                <div className="p-3 hover:bg-gray-50 rounded-lg cursor-pointer">
                  <div className="font-medium">Digital Electronics Lab Manual</div>
                  <div className="text-sm text-gray-500">Electronics - 4th Semester</div>
                </div>
              </div>
            </div>
          )}

          {query && searchResults.length === 0 && !isSearching && (
            <div className="text-center py-8">
              <Search className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No results found for "{query}"</p>
              <p className="text-sm text-gray-400 mt-1">Try different keywords or check spelling</p>
            </div>
          )}

          {searchResults.length > 0 && (
            <div className="space-y-3">
              <div className="text-sm text-gray-500 mb-3">
                Found {searchResults.length} result(s) for "{query}"
              </div>
              {searchResults.map((material) => (
                <div
                  key={material.id}
                  className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        {getFileIcon(material.fileType)}
                        <h3 className="font-semibold text-gray-900">{material.title}</h3>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{material.description}</p>
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge className={`text-xs ${getTypeColor(material.type)}`}>
                          {getTypeLabel(material.type)}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {material.branchCode.toUpperCase()}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          Sem {material.semester}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {material.subject}
                        </Badge>
                      </div>
                      <div className="flex items-center text-xs text-gray-500 mt-2">
                        <Download className="h-3 w-3 mr-1" />
                        <span>{material.downloadCount} downloads</span>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => downloadMutation.mutate(material.id)}
                      disabled={downloadMutation.isPending}
                      className="bg-primary hover:bg-blue-700 ml-4"
                    >
                      {downloadMutation.isPending ? "..." : "Download"}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
