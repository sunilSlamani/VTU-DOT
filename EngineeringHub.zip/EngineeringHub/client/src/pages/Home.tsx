import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { LaptopIcon, Cog, Building, Zap, Database, Microchip, Book, FileText, FlaskConical } from "lucide-react";
import { AppStats, BranchData } from "@/types";

export default function Home() {
  const { data: stats } = useQuery<AppStats>({
    queryKey: ['/api/stats']
  });

  const { data: branches = [] } = useQuery<BranchData[]>({
    queryKey: ['/api/branches']
  });

  const getBranchIcon = (iconClass: string) => {
    switch (iconClass) {
      case 'fas fa-laptop-code':
        return <LaptopIcon className="text-primary text-xl" />;
      case 'fas fa-microchip':
        return <Microchip className="text-secondary text-xl" />;
      case 'fas fa-cogs':
        return <Cog className="text-accent text-xl" />;
      case 'fas fa-building':
        return <Building className="text-purple-600 text-xl" />;
      case 'fas fa-bolt':
        return <Zap className="text-yellow-600 text-xl" />;
      case 'fas fa-database':
        return <Database className="text-red-600 text-xl" />;
      default:
        return <Book className="text-gray-600 text-xl" />;
    }
  };

  const getIconBgColor = (iconClass: string) => {
    switch (iconClass) {
      case 'fas fa-laptop-code':
        return 'bg-blue-100';
      case 'fas fa-microchip':
        return 'bg-green-100';
      case 'fas fa-cogs':
        return 'bg-orange-100';
      case 'fas fa-building':
        return 'bg-purple-100';
      case 'fas fa-bolt':
        return 'bg-yellow-100';
      case 'fas fa-database':
        return 'bg-red-100';
      default:
        return 'bg-gray-100';
    }
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-blue-800 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              VTU Dot
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
              Complete academic resource platform for Visvesvaraya Technological University students. Access verified study materials, previous year question papers, lab manuals, and comprehensive academic content across all engineering disciplines.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                asChild
                className="bg-white text-primary px-8 py-3 text-base font-semibold hover:bg-gray-100"
              >
                <Link href="/materials">Browse Study Materials</Link>
              </Button>
              <Button 
                asChild
                variant="outline"
                className="border-2 border-white text-white px-8 py-3 text-base font-semibold hover:bg-white hover:text-primary"
              >
                <Link href="/papers">Download Question Papers</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Stats */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{stats?.branches || 0}+</div>
              <div className="text-gray-600">Engineering Branches</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{stats?.materials || 0}+</div>
              <div className="text-gray-600">Study Materials</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{stats?.papers || 0}+</div>
              <div className="text-gray-600">Question Papers</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">{stats?.labs || 0}+</div>
              <div className="text-gray-600">Lab Manuals</div>
            </div>
          </div>
        </div>
      </section>

      {/* Engineering Branches */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              VTU Engineering Branches
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Explore comprehensive academic resources for all Visvesvaraya Technological University engineering programs. Each branch contains semester-wise organized study materials, previous year examination papers, practical lab manuals, and subject-specific content curated by academic experts.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {branches.map((branch) => (
              <Link key={branch.code} href={`/branch/${branch.code}`}>
                <Card className="hover:shadow-xl transition-shadow cursor-pointer h-full">
                  <CardContent className="p-6">
                    <div className={`w-12 h-12 ${getIconBgColor(branch.icon)} rounded-lg flex items-center justify-center mb-4`}>
                      {getBranchIcon(branch.icon)}
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{branch.name}</h3>
                    <p className="text-gray-600 mb-4">{branch.description}</p>
                    <div className="flex justify-between text-sm text-gray-500">
                      <span>VTU Approved Content</span>
                      <span>All 8 Semesters</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Complete Academic Resource Hub
            </h2>
            <p className="text-lg text-gray-600 max-w-4xl mx-auto">
              Access verified academic content including detailed study notes, solved previous year question papers with marking schemes, comprehensive lab manuals with practical exercises, semester-wise syllabus coverage, and expert-curated materials for all VTU engineering subjects across 8 semesters.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Book className="text-primary text-2xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Study Materials</h3>
              <p className="text-gray-600">Comprehensive lecture notes, textbooks, reference materials, solved examples, and detailed explanations covering complete VTU syllabus for all engineering subjects</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="text-secondary text-2xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Question Papers</h3>
              <p className="text-gray-600">Previous year VTU examination papers with detailed solutions, marking schemes, time allocation guides, and semester-wise categorized papers for effective exam preparation</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <FlaskConical className="text-accent text-2xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Lab Manuals</h3>
              <p className="text-gray-600">Complete practical lab manuals with step-by-step procedures, circuit diagrams, program codes, expected results, and viva questions for all laboratory sessions</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
