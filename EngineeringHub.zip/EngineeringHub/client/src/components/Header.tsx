import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Search, Menu, LogOut } from "lucide-react";
import { LoginModal } from "./LoginModal";
import { SearchModal } from "./SearchModal";
import { apiRequest } from "@/lib/queryClient";
import { clearAuthSession } from "@/lib/auth";
import { AuthUser } from "@/types";

export function Header() {
  const [location] = useLocation();
  const [showLogin, setShowLogin] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const { data: authData } = useQuery<{ user: AuthUser } | null>({
    queryKey: ['/api/auth/me'],
    retry: false
  });

  const user = authData?.user;

  const handleLogout = async () => {
    try {
      await apiRequest('POST', '/api/auth/logout');
      clearAuthSession();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const navLinks = [
    { href: "/", label: "Home", active: location === "/" },
    { href: "/branches", label: "Branches", active: location === "/branches" },
    { href: "/resources", label: "Resources", active: location === "/resources" },
    { href: "/about", label: "About", active: location === "/about" }
  ];

  return (
    <>
      <header className="bg-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo Section */}
            <Link href="/" className="flex items-center space-x-3">
              <div className="bg-primary text-white w-10 h-10 rounded-lg flex items-center justify-center font-bold text-lg">
                VD
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-semibold text-gray-900">VTU Dot</span>
                <span className="text-xs text-gray-500">www.vtudot.com - Your Academic Partner</span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`${
                    link.active
                      ? "text-primary border-b-2 border-primary font-medium"
                      : "text-gray-700 hover:text-primary transition-colors"
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </nav>

            {/* User Section */}
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowSearch(true)}
                className="text-gray-600 hover:text-primary"
              >
                <Search className="h-5 w-5" />
              </Button>

              {user ? (
                <div className="flex items-center space-x-3">
                  <span className="text-sm text-gray-700 hidden sm:block">{user.name}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleLogout}
                    className="text-gray-500 hover:text-primary"
                  >
                    <LogOut className="h-4 w-4 mr-1" />
                    <span className="hidden sm:inline">Logout</span>
                  </Button>
                </div>
              ) : (
                <Button
                  onClick={() => setShowLogin(true)}
                  className="bg-primary text-white hover:bg-blue-700"
                >
                  Login
                </Button>
              )}

              {/* Mobile Menu Button */}
              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-64">
                  <div className="flex flex-col space-y-4 mt-6">
                    {navLinks.map((link) => (
                      <Link
                        key={link.href}
                        href={link.href}
                        className={`block py-2 ${
                          link.active ? "text-primary font-medium" : "text-gray-700"
                        }`}
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        {link.label}
                      </Link>
                    ))}
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>

      <LoginModal open={showLogin} onOpenChange={setShowLogin} />
      <SearchModal open={showSearch} onOpenChange={setShowSearch} />
    </>
  );
}
