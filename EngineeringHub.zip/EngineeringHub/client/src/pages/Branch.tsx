import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Download, FileText, Search } from "lucide-react";
import { BranchData, MaterialData } from "@/types";
import { apiRequest } from "@/lib/queryClient";

export default function Branch() {
  const { code } = useParams<{ code: string }>();
  const [activeTab, setActiveTab] = useState("materials");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSemester, setSelectedSemester] = useState<string>("all");
  const [selectedSubject, setSelectedSubject] = useState<string>("all");

  const { data: branch } = useQuery<BranchData>({
    queryKey: [`/api/branches/${code}`],
    enabled: !!code
  });

  const { data: allMaterials = [] } = useQuery<MaterialData[]>({
    queryKey: [`/api/materials?branch=${code}`],
    enabled: !!code
  });

  const downloadMutation = useMutation({
    mutationFn: async (materialId: number) => {
      const response = await apiRequest('POST', `/api/materials/${materialId}/download`);
      return response.json();
    },
    onSuccess: (data) => {
      const link = document.createElement('a');
      link.href = data.fileUrl;
      link.download = data.fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  });

  if (!branch) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Branch not found</h1>
          <Link href="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  const getBranchIcon = (iconClass: string) => {
    return <i className={`${iconClass} text-white text-2xl`}></i>;
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'study_material':
        return 'bg-blue-100 text-blue-700';
      case 'question_paper':
        return 'bg-red-100 text-red-700';
      case 'lab_manual':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getFileIcon = () => {
    return <FileText className="text-gray-600" />;
  };

  const filterMaterials = (type?: string) => {
    return allMaterials.filter(material => {
      const matchesType = !type || material.type === type;
      const matchesSearch = !searchQuery || 
        material.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        material.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        material.subject.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesSemester = selectedSemester === "all" || material.semester === parseInt(selectedSemester);
      const matchesSubject = selectedSubject === "all" || material.subject === selectedSubject;
      
      return matchesType && matchesSearch && matchesSemester && matchesSubject;
    });
  };

  const studyMaterials = filterMaterials('study_material');
  const questionPapers = filterMaterials('question_paper');
  const labManuals = filterMaterials('lab_manual');

  const uniqueSubjects = Array.from(new Set(allMaterials.map(m => m.subject)));

  const renderMaterialGrid = (materials: MaterialData[]) => {
    if (materials.length === 0) {
      return (
        <div className="text-center py-8">
          <FileText className="h-12 w-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">No materials found</p>
          <p className="text-sm text-gray-400 mt-1">Try adjusting your filters</p>
        </div>
      );
    }

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {materials.map((material) => (
          <Card key={material.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                  {getFileIcon()}
                </div>
                <div className="flex gap-2">
                  <Badge variant="outline" className="text-xs">
                    {material.semester}th Sem
                  </Badge>
                  {material.examDate && (
                    <Badge className={`text-xs ${getTypeColor(material.type)}`}>
                      {material.examDate}
                    </Badge>
                  )}
                </div>
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">{material.title}</h3>
              <p className="text-sm text-gray-600 mb-4 line-clamp-2">{material.description}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center text-xs text-gray-500">
                  <Download className="h-3 w-3 mr-1" />
                  <span>{material.downloadCount} downloads</span>
                </div>
                <Button
                  size="sm"
                  onClick={() => downloadMutation.mutate(material.id)}
                  disabled={downloadMutation.isPending}
                  className="bg-primary hover:bg-blue-700"
                >
                  {downloadMutation.isPending ? "..." : "Download"}
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  return (
    <div>
      {/* Branch Header */}
      <section className="bg-primary text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center mb-4">
            <Link href="/">
              <Button variant="ghost" size="icon" className="text-white hover:text-gray-200 mr-4">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <nav className="text-sm">
              <span className="text-gray-300">Home</span>
              <span className="mx-2">/</span>
              <span>{branch.name}</span>
            </nav>
          </div>
          <div className="flex items-center">
            <div className="w-16 h-16 bg-white bg-opacity-20 rounded-lg flex items-center justify-center mr-6">
              {getBranchIcon(branch.icon)}
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-2">{branch.name}</h1>
              <p className="text-lg text-gray-200">{branch.description}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Content Area */}
      <section className="py-8 bg-gray-50 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Filters */}
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search materials..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={selectedSemester} onValueChange={setSelectedSemester}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Semesters</SelectItem>
                    {[1, 2, 3, 4, 5, 6, 7, 8].map(sem => (
                      <SelectItem key={sem} value={sem.toString()}>{sem}th Semester</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Subjects</SelectItem>
                    {uniqueSubjects.map(subject => (
                      <SelectItem key={subject} value={subject}>{subject}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Content Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="materials">Study Materials ({studyMaterials.length})</TabsTrigger>
              <TabsTrigger value="papers">Question Papers ({questionPapers.length})</TabsTrigger>
              <TabsTrigger value="labs">Lab Manuals ({labManuals.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="materials">
              {renderMaterialGrid(studyMaterials)}
            </TabsContent>

            <TabsContent value="papers">
              {renderMaterialGrid(questionPapers)}
            </TabsContent>

            <TabsContent value="labs">
              {renderMaterialGrid(labManuals)}
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  );
}
